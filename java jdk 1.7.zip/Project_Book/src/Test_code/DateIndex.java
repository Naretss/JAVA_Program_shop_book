package Test_code;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateIndex {
    public static void main(String[] args){
        
    Calendar c = Calendar.getInstance();
    System.out.println("Current Date : " + c.getTime()); 
		
    }
} 